import SwiftUI

struct AddVacationEventView: View {
    @Environment(\.presentationMode) var presentationMode
    let selectedDate: Date
    @State private var title: String = ""

    var onSave: (CalendarEvent) -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Detalles de las Vacaciones")) {
                    Text("Fecha: \(selectedDate, formatter: dateFormatter)")
                    TextField("Descripción (opcional)", text: $title)
                }
            }
            .navigationTitle("Añadir Vacaciones")
            .navigationBarItems(leading: Button("Cancelar") {
                presentationMode.wrappedValue.dismiss()
            }, trailing: Button("Guardar") {

                let newEvent = CalendarEvent(date: selectedDate,
                                             type: .vacaciones,
                                             title: title.isEmpty ? "Vacaciones" : title)
                onSave(newEvent)
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
    

    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }
}
