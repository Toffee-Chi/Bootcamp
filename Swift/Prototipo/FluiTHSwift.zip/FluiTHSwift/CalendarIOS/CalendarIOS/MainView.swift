import SwiftUI

struct MainView: View {
    @State private var selectedTab: Int = 0

    var body: some View {
        ZStack(alignment: .bottom) {
            // Muestra la vista principal según la pestaña seleccionada
            Group {
                if selectedTab == 0 {
                    ContentView()
                } else if selectedTab == 1 {
                    // Puedes cambiar esta vista por la que agregue nuevos eventos
                    Text("Agregar Evento")
                } else if selectedTab == 2 {
                    Text("Perfil")
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            // Menú inferior personalizado
            BottomMenuView(selectedTab: $selectedTab)
                .padding(.bottom, 10)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
