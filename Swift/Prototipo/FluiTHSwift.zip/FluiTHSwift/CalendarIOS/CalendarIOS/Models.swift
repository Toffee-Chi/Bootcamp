import Foundation

enum CalendarEventType {
    case vacaciones
    case cumpleanios
    case licencia
    case reposo
    // Agrega más tipos según necesites
}

struct CalendarEvent: Identifiable, Hashable {
    let id: UUID = UUID()  // Identificador único
    let date: Date
    let type: CalendarEventType
    let title: String
    // Otros campos, como nombre del empleado, etc.
}
