import SwiftUI

struct BottomMenuView: View {
    @Binding var selectedTab: Int

    var body: some View {
        HStack {
            Spacer()
            Button(action: { selectedTab = 0 }) {
                VStack {
                    Image(systemName: "calendar")
                        .font(.title2)
                    Text("Calendario")
                        .font(.caption)
                }
            }
            Spacer()
            Button(action: { selectedTab = 1 }) {
                VStack {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                    Text("Agregar")
                        .font(.caption)
                }
            }
            Spacer()
            Button(action: { selectedTab = 2 }) {
                VStack {
                    Image(systemName: "person.crop.circle")
                        .font(.title2)
                    Text("Perfil")
                        .font(.caption)
                }
            }
            Spacer()
        }
        .padding()
        .background(.ultraThinMaterial) // Fondo translúcido
        .cornerRadius(25)
        .shadow(radius: 10)
        .padding(.horizontal)
    }
}

struct BottomMenuView_Previews: PreviewProvider {
    static var previews: some View {
        BottomMenuView(selectedTab: .constant(0))
            .previewLayout(.sizeThatFits)
    }
}
