//
//  CalendarIOSApp.swift
//  CalendarIOS
//
//  Created by Bootcamp on 2025-04-02.
//

import SwiftUI

@main
struct CalendarIOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
