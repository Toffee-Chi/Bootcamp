import SwiftUI
import SwiftData

struct LeaveListView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var leaves: [LeaveRequest]
    @State private var showingAddView = false
    
    var body: some View {
        NavigationStack {
            VStack {
                Group {
                    if leaves.isEmpty {
                        ContentUnavailableView(
                            "No hay solicitudes",
                            systemImage: "doc.text",
                            description: Text("Agregue una nueva solicitud")
                        )
                    } else {
                        List {
                            ForEach(leaves) { leave in
                                LeaveCardView(leave: leave)
                                    .swipeActions {
                                        Button(role: .destructive) {
                                            deleteLeave(leave)
                                        } label: {
                                            Label("Eliminar", systemImage: "trash")
                                        }
                                    }
                            }
                        }
                    }
                }
                
                .toolbar {
                    ToolbarItem(placement: .primaryAction) {
                        NavigationLink(destination: LeaveFormView()) {
                            Image(systemName: "plus")
                        }
                        .navigationTitle("Solicitudes")
                    }
                }
            }
        }
    }
    
    private func deleteLeave(_ leave: LeaveRequest) {
        modelContext.delete(leave)
    }
}

struct LeaveCardView: View {
    let leave: LeaveRequest
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(leave.employeeName)
                    .font(.headline)
                Spacer()
                statusBadge
            }
            
            Text("\(formattedDateRange)")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            
            Text("\(leave.type.rawValue)")
                .font(.caption)
            
            if let subtype = leave.licenseSubtype {
                Text("Tipo: \(subtype.rawValue)")
                    .font(.caption)
            }
            
            if let relationship = leave.deathRelationship {
                Text("Parentesco: \(relationship.rawValue)")
                    .font(.caption)
            }
            
            if let gender = leave.gender {
                if gender == .female {
                    Text("Mama roshkera")
                        .font(.caption)
                } else {
                    Text("Papa roshkero")
                        .font(.caption)
                }
            }
        }
        .padding(.vertical, 8)
    }
    
    private var formattedDateRange: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return "\(formatter.string(from: leave.startDate)) - \(formatter.string(from: leave.endDate))"
    }
    
    private var statusBadge: some View {
        Text(leave.status)
            .font(.caption)
            .padding(4)
            .background(statusColor)
            .cornerRadius(4)
    }
    
    private var statusColor: Color {
        switch leave.status {
        case "PENDIENTE": return .orange
        case "APROBADO": return .green
        case "RECHAZADO": return .red
        default: return .gray
        }
    }
}

#Preview {
    LeaveListView()
        .modelContainer(for: LeaveRequest.self, inMemory: true)
}


