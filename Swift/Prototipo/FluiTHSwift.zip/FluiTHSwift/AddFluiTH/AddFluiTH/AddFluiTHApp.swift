//
//  AddFluiTHApp.swift
//  AddFluiTH
//
//  Created by Bootcamp on 4/8/25.
//

import SwiftUI
import SwiftData

@main
struct AddFluiTHApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .modelContainer(for: LeaveRequest.self)
        }
    }
}
