//
//  VacacionesApp.swift
//  Vacaciones
//
//  Created by Bootcamp on 2025-04-03.
//

import SwiftUI

@main
struct VacacionesApp: App {
    var body: some Scene {
        WindowGroup {
            VacacionesView()
        }
    }
}
