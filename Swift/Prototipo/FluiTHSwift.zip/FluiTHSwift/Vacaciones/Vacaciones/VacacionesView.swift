
import Foundation

import SwiftUI

struct VacacionesView: View {
    @State private var solicitudes: [Solicitud] = []
    
    var body: some View {
        NavigationView {
            if solicitudes.isEmpty {
                VStack {
                    ProgressView()
                    Text("Cargando solicitudes...")
                        .foregroundColor(.gray)
                }
            } else {
                List(solicitudes) { solicitud in
                    VStack(alignment: .leading, spacing: 6) {
                        Text("👤 \(solicitud.usuario.nombre) \(solicitud.usuario.apellido)")
                            .font(.headline)
                        Text("📅 Desde: \(solicitud.fechaInicio)")
                        Text("📅 Hasta: \(solicitud.fechaFin)")
                        Text("📌 Estado: \(solicitud.estado ? "✅ Aprobado" : "⏳ Pendiente")")
                            .foregroundColor(solicitud.estado ? .green : .orange)
                    }
                    .padding(.vertical, 4)
                }
                .listStyle(PlainListStyle())
                .navigationTitle("Vacaciones")
            }
        }
        .onAppear {
            VacacionesService.shared.obtenerVacaciones { datos in
                print("🟢 Llamando a setState con \(datos.count) solicitudes")
                self.solicitudes = datos
            }
        }
    }
}
