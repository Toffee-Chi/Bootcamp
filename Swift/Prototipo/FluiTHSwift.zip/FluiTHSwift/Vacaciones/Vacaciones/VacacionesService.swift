import Foundation
class VacacionesService {
    static let shared = VacacionesService()
    
    func obtenerVacaciones(completion: @escaping ([Solicitud]) -> Void) {
        guard let url = URL(string: "https://bootcamp.iservers.roshka.com/api/vacaciones/solicitudes") else {
            print("URL inválida")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJmYWJyaWNjaW9waXN0aWxsaTQwQGdtYWlsLmNvbSIsInVzdWFyaW9JZCI6MTg4LCJyb2wiOiJUSCIsImlhdCI6MTc0NDAzMjIzNiwiZXhwIjoxNzQ0MTE4NjM2fQ.tnTuVgRIlchhlbX4epUKjYG40FhVX5aJkRbWa0gkrmCOB1WpT2d6_fZi2X0ICd7ZCH370rpbavvvc9zTbadDdQ", forHTTPHeaderField: "Authorization")

        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                let rawString = String(data: data, encoding: .utf8) ?? " No se pudo convertir a texto"
                print("Respuesta cruda del servidor:")
                print(rawString)

                do {
                    let solicitudes = try JSONDecoder().decode([Solicitud].self, from: data)
                    DispatchQueue.main.async {
                        completion(solicitudes)
                    }
                } catch {
                    print(" Error al decodificar JSON: \(error)")
                }
            

            } else if let error = error {
                print("Error en la petición: \(error)")
            }
        }.resume()
    }
}
