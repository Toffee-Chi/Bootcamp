import Foundation


struct Solicitud: Codable, Identifiable{
    let id: Int
    let usuario: Usuario
    let lideres: [Usuario]
    let fechaInicio, fechaFin: String
    let estado: Bool
    let numeroAprobaciones, cantidadDias: Int
    let comentario: String
    let rechazado: Bool
}

// MARK: - Usuario
struct Usuario: Codable{
    let id: Int
    let nombre, apellido: String
    let requiereCambioContrasena: Bool
    let nroCedula: Int
    let correo, fechaNacimiento, contrasena, telefono: String
    let fechaIngreso, antiguedad: String
    let diasVacaciones, diasVacacionesRestante: Int
    let estado: Bool
    let rol, equipo, cargo: Cargo
}

// MARK: - Cargo
struct Cargo: Codable{
    let id: Int
    let nombre: String
}
