import SwiftUI
@main
struct FluiTHApp: App {
    @State private var isLoginSuccessful = false
    
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                if !isLoginSuccessful {
                    LoginView(isLoginSuccessful: $isLoginSuccessful)  // Cambiado de Login a LoginView
                } else {
                    MainContainerView(onLogout: {
                        isLoginSuccessful = false
                    })
                    .navigationBarBackButtonHidden(true)
                }
            }
        }
    }
}
