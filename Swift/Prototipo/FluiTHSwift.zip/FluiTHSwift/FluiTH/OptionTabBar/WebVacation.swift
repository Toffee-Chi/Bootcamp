import Foundation
import SwiftUI
struct WebVacation: View {
    var body: some View {
        Text("Vista vacacion jaja")
            .font(.caption)
            .foregroundColor(.gray)
    }
}
struct WebVacation_Previews: PreviewProvider {
    static var previews: some View {
        WebVacation()
    }
}
