import Foundation
import SwiftUI
struct DialogView: View {
    var body: some View {
        LeaveListView()
    }
}
struct DialogView_Previews: PreviewProvider {
    static var previews: some View {
        DialogView()
    }
}
