//import SwiftUI
//import SwiftData
//
//struct LeaveListView: View {
//    @Environment(\.modelContext) private var modelContext
//    @Query private var leaves: [LeaveRequest]
//    @State private var showingAddView = false
//    
//    var body: some View {
//        NavigationStack {
//            VStack {
//                    if leaves.isEmpty {
//                        ContentUnavailableView(
//                            "No hay solicitudes",
//                            systemImage: "doc.text",
//                            description: Text("Agregue una nueva solicitud")
//                        )
//                    } else {
//                        List {
//                            ForEach(leaves) { leave in
//                                LeaveCardView(leave: leave)
//                                    .swipeActions {
//                                        Button(role: .destructive) {
//                                            deleteLeave(leave)
//                                        } label: {
//                                            Label("Eliminar", systemImage: "trash")
//                                        }
//                                    }
//                            }
//                        }
//                    }
//                
//                .toolbar {
//                    ToolbarItem(placement: .primaryAction) {
//                        NavigationLink(destination: LeaveFormView()) {
//                            Image(systemName: "plus")
//                        }
//                        .navigationTitle("Solicitudes")
//                    }
//                }
//            }
//        }
//    }
//    
//    private func deleteLeave(_ leave: LeaveRequest) {
//        modelContext.delete(leave)
//    }
//}
//
//    
//    
//    #Preview {
//        LeaveListView()
//            .modelContainer(for: LeaveRequest.self, inMemory: true)
//    }
//
import SwiftUI
import SwiftData
import Kingfisher

struct LeaveListView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var leaves: [LeaveRequest]
    
    @State private var showingAddView = false
    @State private var expandedLeaveID: PersistentIdentifier? = nil
    
    var body: some View {
        NavigationStack {
            VStack {
                Group {
                    if leaves.isEmpty {
                        ContentUnavailableView(
                            "No hay solicitudes",
                            systemImage: "doc.text",
                            description: Text("Agregue una nueva solicitud")
                        )
                    } else {
                        List {
                       // VStack(spacing: 12) {
                                ForEach(leaves) { leave in
                                    LeaveCardView(
                                        leave: leave,
                                        isExpanded: expandedLeaveID == leave.persistentModelID,
                                        onTap: {
                                            withAnimation {
                                                if expandedLeaveID == leave.persistentModelID {
                                                    expandedLeaveID = nil
                                                } else {
                                                    expandedLeaveID = leave.persistentModelID
                                                }
                                            }
                                    }
                                    )
                                    .swipeActions {
                                        Button(role: .destructive) {
                                            deleteLeave(leave)
                                        } label: {
                                            Label("Eliminar", systemImage: "trash")
                                        }
                                    }
//                                    .padding(.horizontal)
                                }
                            // }
//                            .padding(.top)
                        }
                        .background(Color.red)
                    }
                }
                .toolbar {
                    ToolbarItem(placement: .primaryAction) {
                        NavigationLink(destination: LeaveFormView()) {
                            Image(systemName: "plus")
                        }
                    }
                }
            }
            .navigationTitle("Solicitudes")
        }
    }
    
    private func deleteLeave(_ leave: LeaveRequest) {
        modelContext.delete(leave)
    }
}


#Preview {
    LeaveListView()
        .modelContainer(for: LeaveRequest.self, inMemory: true)
}
