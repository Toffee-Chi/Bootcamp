# 📱 FluiTH - Gestión de Recursos Humanos
Aplicación móvil, prototipo para gestión de vacaciones, cumpleaños, licencias y funcionarios (Bootcamp Roshka).

## 📌 Características Principales
- ✅ Login Autenticado.
- ✅ Calendarios de Licencias, Cumpleaños y Vacaciones.
- ✅ Solicitud de vacaciones con aprobación pendiente.
- ✅ Visualización de estado de funcionarios por equipos.
- ✅ Menú hamburguesa con navegación personalizada.
- ✅ Generacion de Vacaciones, Reposos con comprobante medico y Licencias de acuerdo al caso.

## 🛠 Tecnologías Usadas
- SwiftUI + UIKit
- SwiftData (para persistencia local)
- Keychain para autenticación segura
- PhotosUI
- Kingfisher
- CoreData

## 🔧 Requisitos
- Xcode 15+
- iOS 18+
- Kingfisher (para dependencias)

## 🚀 Pasos para tener el entorno Web: 
- Instalado IntelliJ
- Instalado PostGreSQL
- Tener Proyecto Vacaciones-develop
- Credentials JSON
- BD FINAL, para el postgresql
- SDK 21 o SDK 23
- Debug de Maven en IntelliJ, spring-boot: run
- El proyecto del IntelliJ debe de estar en SDK 21, tanto como el Module y su Languaje.
- Listo!
