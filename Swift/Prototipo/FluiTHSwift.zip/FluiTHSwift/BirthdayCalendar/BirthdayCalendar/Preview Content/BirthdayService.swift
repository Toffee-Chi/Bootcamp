import Foundation

class BirthdayService {
    static let shared = BirthdayService()
    
    func obtenerCumpleanieros(fecha: Date, completion: @escaping ([Birthday]) -> Void) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        _ = formatter.string(from: fecha)
        
        guard let url = URL(string: "https://bootcamp.iservers.roshka.com/api/vacaciones/listarusuarios") else {
            print("URL inválida")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJmYWJyaWNjaW9waXN0aWxsaTQwQGdtYWlsLmNvbSIsInVzdWFyaW9JZCI6MTg4LCJyb2wiOiJUSCIsImlhdCI6MTc0NDExODgxMCwiZXhwIjoxNzQ0MjA1MjEwfQ.CYqHxAsV2JDZtzC5chnojQ3jgOkT0icZfdXgfCCnaH0Eegs8tpxyBA1KOcJwQXFtdbIFDJAtva3JqegH79L-lw", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                let rawString = String(data: data, encoding: .utf8) ?? "No se pudo convertir a texto"
                print("Respuesta cruda del servidor:")
                print(rawString)
                
                do {
                    let cumpleanieros = try JSONDecoder().decode([Birthday].self, from: data)
                    DispatchQueue.main.async {
                        completion(cumpleanieros)
                    }
                } catch {
                    print("Error al decodificar JSON: \(error)")
                }
            } else if let error = error {
                print("Error en la petición: \(error)")
            }
        }.resume()
    }
}


