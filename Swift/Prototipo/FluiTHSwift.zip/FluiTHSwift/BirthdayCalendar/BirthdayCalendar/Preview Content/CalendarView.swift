import SwiftUI

struct CalendarView: View {
    @StateObject private var viewModel = CalendarViewModel()

    var body: some View {
        NavigationView {
            VStack {
                Text("Cumpleaños")
                    .font(.title)
                    .bold()
                    .padding(.top)

                MonthCalendarView(selectedDate: $viewModel.selectedDate)

                Text("Hoy")
                    .font(.headline)
                    .padding(.top)

                BirthdayListView(birthdays: viewModel.birthdays)

                Spacer()
            }
            .onChange(of: viewModel.selectedDate) {
                viewModel.updateDate(to: viewModel.selectedDate)
            }

        }
    }
}

