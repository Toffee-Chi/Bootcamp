import Foundation
import Combine

class CalendarViewModel: ObservableObject {
    @Published var birthdays: [Birthday] = []
    @Published var selectedDate: Date = Date()

    init() {
        fetchBirthdays(for: selectedDate)
    }

    func fetchBirthdays(for date: Date) {
        BirthdayService.shared.obtenerCumpleanieros(fecha: date) { [weak self] cumpleanieros in
            DispatchQueue.main.async {
                self?.birthdays = cumpleanieros
            }
        }
    }

    func updateDate(to newDate: Date) {
        selectedDate = newDate
        fetchBirthdays(for: newDate)
    }
}
