//
//  BirthdayCalendarApp.swift
//  BirthdayCalendar
//
//  Created by Bootcamp on 2025-04-08.
//

import SwiftUI

@main
struct BirthdayCalendarApp: App {
    var body: some Scene {
        WindowGroup {
            CalendarView()
        }
    }
}
