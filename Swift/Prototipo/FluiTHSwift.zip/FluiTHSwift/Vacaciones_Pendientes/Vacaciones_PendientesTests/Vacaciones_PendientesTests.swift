//
//  Vacaciones_PendientesTests.swift
//  Vacaciones_PendientesTests
//
//  Created by bootcamp on 2025-04-03.
//

import Testing
@testable import Vacaciones_Pendientes

struct Vacaciones_PendientesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
