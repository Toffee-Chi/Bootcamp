//
//  Vacaciones_PendientesApp.swift
//  Vacaciones_Pendientes
//
//  Created by bootcamp on 2025-04-03.
//

import SwiftUI

@main
struct Vacaciones_PendientesApp: App {
    var body: some Scene {
        WindowGroup {
        }
    }
}
