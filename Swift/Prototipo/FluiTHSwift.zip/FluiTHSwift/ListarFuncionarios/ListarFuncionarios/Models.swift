import Foundation

enum Estado {
    case verde //Online
    case amarillo //Ausente
    case rojo //Desconectado
}

struct Funcionario: Identifiable {
    let id = UUID()
    let nombre: String
    let estado: Estado
}

struct Empresa: Identifiable {
    let id = UUID()
    let nombre: String
    let funcionarios: [Funcionario]
}
