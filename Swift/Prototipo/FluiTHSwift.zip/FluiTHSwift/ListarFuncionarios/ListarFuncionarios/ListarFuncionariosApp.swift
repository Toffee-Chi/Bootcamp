
import SwiftUI

@main
struct ListarFuncionariosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
